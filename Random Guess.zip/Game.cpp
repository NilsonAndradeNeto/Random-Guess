
#include <iostream>
#include <time.h>
using namespace std;

int main(){
    // variaveis
    int i, i1, i2, i3, i4, i5;                         //(i)=INFORMACAO e a variavel principal numeros digitado pelo usuario
    int numero1, numero2, numero3, numero4, numero5;  //(numero) e a variavel dos numeros aleatorio
    int pp=0, pi=0;                                  //variavel de (PP) possisao correta e (PI)incorreta
    int dificuldade;                                //variavel para dificuldade
    int c1=1;                                      //variavel comum

    // loop principal do while
    do{
        srand(time(NULL));

        system("color f");




        cout << "\n\n\n\n\n";
        cout <<"                       ________________________________________________   "<<endl;
        cout <<"                      /                                                \\ "<<endl;
        cout <<"                     |    _________________________________________     | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |             1-JOGAR                     |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |             2-DIFICULDADE               |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |             3-DESENVOLVEDORES           |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |             4- SAIR                     |    | "<<endl;
        cout <<"                     |   |                                         |    | "<<endl;
        cout <<"                     |   |_________________________________________|    | "<<endl;
        cout <<"                     |                                                  | "<<endl;
        cout <<"                     \\_________________________________________________/ "<<endl;
        cout <<"                              \\___________________________________/      "<<endl;
        cout <<"                           ___________________________________________    "<<endl;
        cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
        cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
        cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
        cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
        cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
        cout <<"           :-------------------------------------------------------------------------:"<<endl;
        cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

        cout<< " >>";cin >> i;

        system("cls");

        // switch com 3 case 1 para jogar o 2 para dificuldade 3 desenvolvedores
        switch(i){

        case 1:

            pp=0;
            pi=0;

            // loop para gerar numeros aleatorios
            do{
                numero1=rand()%6+1;
                numero2=rand()%6+1;
                numero3=rand()%6+1;
                numero4=rand()%6+1;
            }
            while(numero1==numero2||numero1==numero3||numero1==numero4||numero2==numero3||numero2==numero4|| numero3==numero4);

            //local para ver a sequencia somente desabilitar o //  ou adicionar 0 // para ver nao ver
            cout <<numero1 << numero2 << numero3 << numero4<< endl;

            //loop for para a armazenar as informacoes c11 eo nosso contador para todas as dificuldades
            c1=1;
            for(int c11 = 1; c11 <= 10; c11++) {
                if (c11 == 10)
                    c1=0;

                cout<< " digite uma sequencia de numeros de 1 a 6 " << endl;
                cout<<"\n";
                cout<<"                                                           tentavivas :"<< (11-c11) <<endl;
                cout<<"                                                           possicao correta :"<< pp << endl;
                cout<<"                                                           possicao incorreta :"<< pi <<endl;
                cout<<"\n";
                cout<<"sequencia"<<endl;
                cin >> i1 >> i2 >> i3 >> i4;


                //if para confirmar se os digit0s e as posicoes digitas e igual os numero para decidir se voce ganhou
                if(i1==numero1 && i2==numero2 && i3==numero3 && i4==numero4){
                    system("pause");
                    system("cls");
                    system("color 2");
                    cout << "\n\n\n\n\n";
                    cout <<"                       ________________________________________________   "<<endl;
                    cout <<"                      /                                                \\ "<<endl;
                    cout <<"                     |    _________________________________________     | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |     >>    PARABENS, VOCE GANHOU     <<  |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |-----------------------------------------|    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |_________________________________________|    | "<<endl;
                    cout <<"                     |                                                  | "<<endl;
                    cout <<"                     \\_________________________________________________/ "<<endl;
                    cout <<"                              \\___________________________________/      "<<endl;
                    cout <<"                           ___________________________________________    "<<endl;
                    cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                    cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                    cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                    cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                    cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                    cout <<"           :-------------------------------------------------------------------------:"<<endl;
                    cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                    system("pause");
                    break;
                }



                // possisao correta e possisao incorreta

                pp=0;
                pi=0;

                if (numero1 == i1 && numero2 == i2 && numero3 == i3 && numero4 == i4 ) {
                    pp=4;
                    system("cls");
                    break;
                }

                if (numero1 == i1)
                    pp++;
                else if (numero2 == i1 || numero3 == i1 || numero4 == i1)
                    pi++;

                if (numero2 == i2)
                    pp++;
                else if (numero1 == i2 || numero3 == i2 || numero4 == i2)
                    pi++;

                if (numero3 == i3)
                    pp++;
                else if (numero1 == i3 || numero2 == i3 || numero4 == i3)
                    pi++;

                if (numero4 == i4)
                    pp++;
                else if (numero1 == i4 || numero2 == i4 || numero3 == i4)
                    pi++;


                // local para saber se o usuario digitou um numero invalido
                if(i1<1||i1>6){
                    cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                }
                if(i2<1||i2>6){
                    cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                }
                if(i3<1||i3>6){
                    cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                }
                if(i4<1||i4>6){
                    cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                }
                system("pause");
                system("cls");
                cout<<"\n";
                cout<<"\n";

            }

            if (c1 == 0){
                system("color 4");

                cout << "\n\n\n\n\n";
                cout <<"                       ________________________________________________   "<<endl;
                cout <<"                      /                                                \\ "<<endl;
                cout <<"                     |    _________________________________________     | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |     >> INFELIZMENTE, VOCE PERDEU  <<    |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |-----------------------------------------|    | "<<endl;
                cout <<"                     |   |                                         |    | "<<endl;
                cout <<"                     |   |_________________________________________|    | "<<endl;
                cout <<"                     |                                                  | "<<endl;
                cout <<"                     \\_________________________________________________/ "<<endl;
                cout <<"                              \\___________________________________/      "<<endl;
                cout <<"                           ___________________________________________    "<<endl;
                cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                cout <<"           :-------------------------------------------------------------------------:"<<endl;
                cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                system("pause");
            }
            break;



            // local para adicionar dificuldade ainda nao concluido
        case 2:
            system("cls");

            cout << "\n\n\n\n\n";
            cout <<"                       ________________________________________________   "<<endl;
            cout <<"                      /                                                \\ "<<endl;
            cout <<"                     |    _________________________________________     | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |        SELECIONE SUA DIFICULDADE        |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |             1-FACIL                     |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |             2-MEDIO                     |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |             3- DIFICIL                  |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |_________________________________________|    | "<<endl;
            cout <<"                     |                                                  | "<<endl;
            cout <<"                     \\_________________________________________________/ "<<endl;
            cout <<"                              \\___________________________________/      "<<endl;
            cout <<"                           ___________________________________________    "<<endl;
            cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
            cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
            cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
            cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
            cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
            cout <<"           :-------------------------------------------------------------------------:"<<endl;
            cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

            cout <<" >>";cin>> dificuldade;
            pp=0;
            pi=0;
            system("cls");


            if(dificuldade==1) {do{
                    numero1=rand()%6+1;
                    numero2=rand()%6+1;
                    numero3=rand()%6+1;

                }
                while(numero1==numero2||numero1==numero3||numero2==numero3);

                //local para ver a sequencia somente desabilitar o //  ou adicionar 0 // para ver nao ver
                cout <<numero1 << numero2 << numero3 << endl;

                // FOR dificuldade facil para a armazenar as informacoes
                c1=1;
                for(int c11 = 1; c11 <= 8; c11++) {
                    if (c11 == 8)
                        c1=0;

                    cout<< " digite uma sequencia de numeros de 1 a 6 " << endl;
                    cout<<"\n";
                    cout<<"                                                           tentavivas :"<< (9-c11) <<endl;
                    cout<<"                                                           possicao correta :"<< pp << endl;
                    cout<<"                                                           possicao incorreta :"<< pi <<endl;
                    cout<<"\n";
                    cout<<"sequencia"<<endl;
                    cin >> i1 >> i2 >> i3 ;


                    //if para confirmar se os digit0s e as posicoes digitas e igual os numero para decidir se voce ganhou
                    if(i1==numero1 && i2==numero2 && i3==numero3){
                        system("pause");
                        system("cls");
                        system("color 2");
                        cout << "\n\n\n\n\n";
                        cout <<"                       ________________________________________________   "<<endl;
                        cout <<"                      /                                                \\ "<<endl;
                        cout <<"                     |    _________________________________________     | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |     >>    PARABENS, VOCE GANHOU     <<  |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |-----------------------------------------|    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |_________________________________________|    | "<<endl;
                        cout <<"                     |                                                  | "<<endl;
                        cout <<"                     \\_________________________________________________/ "<<endl;
                        cout <<"                              \\___________________________________/      "<<endl;
                        cout <<"                           ___________________________________________    "<<endl;
                        cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                        cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                        cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                        cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                        cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                        cout <<"           :-------------------------------------------------------------------------:"<<endl;
                        cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                        c1=1;
                        system("pause");
                    }



                    // possisao correta e possisao incorreta

                    pp=0;
                    pi=0;

                    if (numero1 == i1 && numero2 == i2 && numero3 == i3 ) {
                        pp=4;
                        system("cls");
                        break;
                    }

                    if (numero1 == i1)
                        pp++;
                    else if (numero2 == i1 || numero3 == i1)
                        pi++;

                    if (numero2 == i2)
                        pp++;
                    else if (numero1 == i2 || numero3 == i2)
                        pi++;

                    if (numero3 == i3)
                        pp++;
                    else if (numero2 == i3 || numero1 == i3)
                        pi++;



                    // local para saber se o usuario digitou um numero invalido
                    if(i1<1||i1>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i2<1||i2>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i3<1||i3>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }

                    system("pause");
                    system("cls");

                    cout<<"\n";
                    cout<<"\n";

                }

                if (c1 == 0){
                    system("color 4");

                    cout << "\n\n\n\n\n";
                    cout <<"                       ________________________________________________   "<<endl;
                    cout <<"                      /                                                \\ "<<endl;
                    cout <<"                     |    _________________________________________     | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |     >> INFELIZMENTE, VOCE PERDEU  <<    |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |-----------------------------------------|    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |_________________________________________|    | "<<endl;
                    cout <<"                     |                                                  | "<<endl;
                    cout <<"                     \\_________________________________________________/ "<<endl;
                    cout <<"                              \\___________________________________/      "<<endl;
                    cout <<"                           ___________________________________________    "<<endl;
                    cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                    cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                    cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                    cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                    cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                    cout <<"           :-------------------------------------------------------------------------:"<<endl;
                    cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                    system("pause");
                }
                break;

            }

            if(dificuldade==2){              // loop para gerar numeros aleatorios
                do{
                    numero1=rand()%6+1;
                    numero2=rand()%6+1;
                    numero3=rand()%6+1;
                    numero4=rand()%6+1;
                }
                while(numero1==numero2||numero1==numero3||numero1==numero4||numero2==numero3||numero2==numero4|| numero3==numero4);

                //local para ver a sequencia somente desabilitar o //  ou adicionar 0 // para ver nao ver
                cout <<numero1 << numero2 << numero3 << numero4<< endl;

                // FOR dificuldade medio para a armazenar as informacoes
                c1=1;
                for(int c11 = 1; c11 <= 10; c11++) {
                    if (c11 == 10)
                        c1=0;

                    cout<< " digite uma sequencia de numeros de 1 a 6 " << endl;
                    cout<<"\n";
                    cout<<"                                                           tentavivas :"<< (11-c11) <<endl;
                    cout<<"                                                           possicao correta :"<< pp << endl;
                    cout<<"                                                           possicao incorreta :"<< pi <<endl;
                    cout<<"\n";
                    cout<<"sequencia"<<endl;
                    cin >> i1 >> i2 >> i3 >> i4;


                    //if para confirmar se os digit0s e as posicoes digitas e igual os numero para decidir se voce ganhou
                    if(i1==numero1 && i2==numero2 && i3==numero3 && i4==numero4){
                        system("pause");
                        system("cls");
                        system("color 2");
                        cout << "\n\n\n\n\n";
                        cout <<"                       ________________________________________________   "<<endl;
                        cout <<"                      /                                                \\ "<<endl;
                        cout <<"                     |    _________________________________________     | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |     >>    PARABENS, VOCE GANHOU     <<  |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |-----------------------------------------|    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |_________________________________________|    | "<<endl;
                        cout <<"                     |                                                  | "<<endl;
                        cout <<"                     \\_________________________________________________/ "<<endl;
                        cout <<"                              \\___________________________________/      "<<endl;
                        cout <<"                           ___________________________________________    "<<endl;
                        cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                        cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                        cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                        cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                        cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                        cout <<"           :-------------------------------------------------------------------------:"<<endl;
                        cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                        c1=1;
                        system("pause");
                    }



                    // possisao correta e possisao incorreta

                    pp=0;
                    pi=0;

                    if (numero1 == i1 && numero2 == i2 && numero3 == i3 && numero4==i4 ) {
                        pp=4;
                        system("cls");
                        break;
                    }

                    if (numero1 == i1)
                        pp++;
                    else if (numero2 == i1 || numero3 == i1 || numero4 == i1)
                        pi++;

                    if (numero2 == i2)
                        pp++;
                    else if (numero1 == i2 || numero3 == i2 || numero4 == i2)
                        pi++;

                    if (numero3 == i3)
                        pp++;
                    else if (numero1 == i3 || numero2 == i3 || numero4 == i3)
                        pi++;

                    if (numero4 == i4)
                        pp++;
                    else if (numero1 == i4 || numero2 == i4 || numero3 == i4)
                        pi++;



                    // local para saber se o usuario digitou um numero invalido
                    if(i1<1||i1>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i2<1||i2>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i3<1||i3>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i4<1||i4>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    system("pause");
                    system("cls");
                    cout<<"\n";
                    cout<<"\n";

                }

                if (c1 == 0){
                    system("color 4");

                    cout << "\n\n\n\n\n";
                    cout <<"                       ________________________________________________   "<<endl;
                    cout <<"                      /                                                \\ "<<endl;
                    cout <<"                     |    _________________________________________     | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |     >> INFELIZMENTE, VOCE PERDEU  <<    |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |-----------------------------------------|    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |_________________________________________|    | "<<endl;
                    cout <<"                     |                                                  | "<<endl;
                    cout <<"                     \\_________________________________________________/ "<<endl;
                    cout <<"                              \\___________________________________/      "<<endl;
                    cout <<"                           ___________________________________________    "<<endl;
                    cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                    cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                    cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                    cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                    cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                    cout <<"           :-------------------------------------------------------------------------:"<<endl;
                    cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                    system("pause");
                }

            }

            if(dificuldade==3){              // loop para gerar numeros aleatorios
                do{
                    numero1=rand()%6+1;
                    numero2=rand()%6+1;
                    numero3=rand()%6+1;
                    numero4=rand()%6+1;
                    numero5=rand()%6+1;
                }
                while(numero1==numero2||numero1==numero3||numero1==numero4||numero1==numero5||numero2==numero3
                      ||numero2==numero4||numero2==numero5|| numero3==numero4 ||numero3==numero5 || numero4==numero5);

                //local para ver a sequencia somente desabilitar o //  ou adicionar 0 // para ver nao ver
                cout <<numero1 << numero2 << numero3 << numero4<< numero5<< endl;

                // loop FOR dificuldade dificil para armazenar as informacoes
                c1=1;
                for(int c11 = 1; c11 <= 12; c11++) {
                    if (c11 == 12)
                        c1=0;

                    cout<< " digite uma sequencia de numeros de 1 a 6 " << endl;
                    cout<<"\n";
                    cout<<"                                                           tentavivas :"<< (13-c11) <<endl;
                    cout<<"                                                           possicao correta :"<< pp << endl;
                    cout<<"                                                           possicao incorreta :"<< pi <<endl;
                    cout<<"\n";
                    cout<<"sequencia"<<endl;
                    cin >> i1 >> i2 >> i3 >> i4 >>i5;


                    //if para confirmar se os digit0s e as posicoes digitas e igual os numero para decidir se voce ganhou
                    if(i1==numero1 && i2==numero2 && i3==numero3 && i4==numero4 && i5==numero5){
                        system("pause");
                        system("cls");
                        system("color 2");
                        cout << "\n\n\n\n\n";
                        cout <<"                       ________________________________________________   "<<endl;
                        cout <<"                      /                                                \\ "<<endl;
                        cout <<"                     |    _________________________________________     | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |     >>    PARABENS, VOCE GANHOU     <<  |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |-----------------------------------------|    | "<<endl;
                        cout <<"                     |   |                                         |    | "<<endl;
                        cout <<"                     |   |_________________________________________|    | "<<endl;
                        cout <<"                     |                                                  | "<<endl;
                        cout <<"                     \\_________________________________________________/ "<<endl;
                        cout <<"                              \\___________________________________/      "<<endl;
                        cout <<"                           ___________________________________________    "<<endl;
                        cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                        cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                        cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                        cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                        cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                        cout <<"           :-------------------------------------------------------------------------:"<<endl;
                        cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                        c1=1;
                        system("pause");
                    }

                    // possisao correta e possisao incorreta

                    pp=0;
                    pi=0;

                    if (numero1 == i1 && numero2 == i2 && numero3 == i3 && numero4==i4 && numero5 == i5) {
                        pp=5;
                        system("cls");
                        break;
                    }

                    if (numero1 == i1)
                        pp++;
                    else if (numero2 == i1 || numero3 == i1 || numero4 == i1 || numero5 == i4)
                        pi++;

                    if (numero2 == i2)
                        pp++;
                    else if (numero1 == i2 || numero3 == i2 || numero4 == i2 || numero5 == i4)
                        pi++;

                    if (numero3 == i3)
                        pp++;
                    else if (numero1 == i3 || numero2 == i3 || numero4 == i3 || numero5 == i4)
                        pi++;

                    if (numero4 == i4)
                        pp++;
                    else if (numero1 == i4 || numero2 == i4 || numero3 == i4 || numero5 == i4)
                        pi++;

                    if (numero5 == i5)
                        pp++;
                    else if (numero1 == i5 || numero2 == i5 || numero3 == i5 || numero4 == i5)
                        pi++;

                    // local para saber se o usuario digitou um numero invalido
                    if(i1<1||i1>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i2<1||i2>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i3<1||i3>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    if(i4<1||i4>6){
                        cout<<"digito incorreto somente numeros de 1 a 6 " << endl;
                    }
                    system("pause");
                    system("cls");
                    cout<<"\n";
                    cout<<"\n";

                }
                if (c1 == 0){
                    system("color 4");

                    cout << "\n\n\n\n\n";
                    cout <<"                       ________________________________________________   "<<endl;
                    cout <<"                      /                                                \\ "<<endl;
                    cout <<"                     |    _________________________________________     | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |     >> INFELIZMENTE, VOCE PERDEU  <<    |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |-----------------------------------------|    | "<<endl;
                    cout <<"                     |   |                                         |    | "<<endl;
                    cout <<"                     |   |_________________________________________|    | "<<endl;
                    cout <<"                     |                                                  | "<<endl;
                    cout <<"                     \\_________________________________________________/ "<<endl;
                    cout <<"                              \\___________________________________/      "<<endl;
                    cout <<"                           ___________________________________________    "<<endl;
                    cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
                    cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
                    cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
                    cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
                    cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
                    cout <<"           :-------------------------------------------------------------------------:"<<endl;
                    cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

                    system("pause");
                }

            }
            break;

            // desenvolvedores
        case 3:
            system("color E");

            cout << "\n\n\n\n\n";
            cout <<"                       ________________________________________________   "<<endl;
            cout <<"                      /                                                \\ "<<endl;
            cout <<"                     |    _________________________________________     | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |           <<DESENVOLVEDORES>>           |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |         >>NILSON ANDRADE NETO<<         |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |          >>HARAN S. DE SOUZA<<          |    | "<<endl;
            cout <<"                     |   |-----------------------------------------|    | "<<endl;
            cout <<"                     |   |              << MESTRE >>               |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |         >>PROF:EDUARDO ALVES<<          |    | "<<endl;
            cout <<"                     |   |                                         |    | "<<endl;
            cout <<"                     |   |-----------------------------------------|    | "<<endl;
            cout <<"                     |   |                            DATA:10/2022 |    | "<<endl;
            cout <<"                     |   |_________________________________________|    | "<<endl;
            cout <<"                     |                                                  | "<<endl;
            cout <<"                     \\_________________________________________________/ "<<endl;
            cout <<"                              \\___________________________________/      "<<endl;
            cout <<"                           ___________________________________________    "<<endl;
            cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
            cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
            cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
            cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
            cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
            cout <<"           :-------------------------------------------------------------------------:"<<endl;
            cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;

            system("pause");

        }

    }while(i!=4);
    system("color E");

    cout << "\n\n\n\n\n";
    cout <<"                       ________________________________________________   "<<endl;
    cout <<"                      /                                                \\ "<<endl;
    cout <<"                     |    _________________________________________     | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |     >> TCHAU TCHAU ATE A PROXIMA <<     |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |                                         |    | "<<endl;
    cout <<"                     |   |-----------------------------------------|    | "<<endl;
    cout <<"                     |   |                                   n.°.  |    | "<<endl;
    cout <<"                     |   |_________________________________________|    | "<<endl;
    cout <<"                     |                                                  | "<<endl;
    cout <<"                     \\_________________________________________________/ "<<endl;
    cout <<"                              \\___________________________________/      "<<endl;
    cout <<"                           ___________________________________________    "<<endl;
    cout <<"                        _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_ " <<endl;
    cout <<"                     _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_" <<endl;
    cout <<"                  _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_" <<endl;
    cout <<"               _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_"<<endl;
    cout <<"            _-'.-.-.-.-.-. .---.-. .-------------------------. .-.---. .---.-.-.-.`-_" <<endl;
    cout <<"           :-------------------------------------------------------------------------:"<<endl;
    cout <<"           ---._.-------------------------------------------------------------._.---'" <<endl;
}

